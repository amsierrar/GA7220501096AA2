use tecquim;

INSERT INTO proveedor VALUES (8923456781,"Quimicos la prueba",3168524598,"Jaime Perez","asd@lkd.com","av 56 09882","Santiago","Chile","sin observaciones");
INSERT INTO proveedor VALUES (2568954782,"casados ",3185478963,"Carolina Gomez","asd@lkd.com","av 56 09882","Buenos Aires","Argentina","sin observaciones");