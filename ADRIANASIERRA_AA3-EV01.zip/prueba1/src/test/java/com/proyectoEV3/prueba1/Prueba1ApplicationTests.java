package com.proyectoEV3.prueba1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Prueba1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
