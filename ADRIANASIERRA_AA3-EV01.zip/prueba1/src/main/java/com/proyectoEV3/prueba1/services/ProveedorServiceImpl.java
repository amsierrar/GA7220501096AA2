package com.proyectoEV3.prueba1.services;

import com.proyectoEV3.prueba1.model.Proveedor;
import com.proyectoEV3.prueba1.repository.ProveedorRepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service


public class ProveedorServiceImpl implements ProveedorService{

    @Autowired//se conecta con el repositorio
    private ProveedorRepository proveedorRepository;


    @Override
    public Proveedor newProveedor(Proveedor newProveedor) {
        return proveedorRepository.save(newProveedor);
    }

    @Override
    public Iterable<Proveedor> getAll() {
        return this.proveedorRepository.findAll();
    }

    @Override
    public Proveedor modifyProveedor(Proveedor proveedor) {
        Optional<Proveedor> proveedorEncontrado=this.proveedorRepository.findById(proveedor.getNit());
        if (proveedorEncontrado.get()!=null) {
            proveedorEncontrado.get().setNombre_proveedor(proveedor.getNombre_proveedor());
            proveedorEncontrado.get().setTel_proveedor(proveedor.getTel_proveedor());
            proveedorEncontrado.get().setContacto_proveedor(proveedor.getContacto_proveedor());
            proveedorEncontrado.get().setCorreo_proveedor(proveedor.getCorreo_proveedor());
            proveedorEncontrado.get().setDir_proveedor(proveedor.getDir_proveedor());
            proveedorEncontrado.get().setCiudad_proveedor(proveedor.getCiudad_proveedor());
            proveedorEncontrado.get().setPais_proveedor(proveedor.getPais_proveedor());
            proveedorEncontrado.get().setObservaciones_proveedor(proveedor.getObservaciones_proveedor());
            return this.newProveedor(proveedorEncontrado.get());
            
        }
        return null;
    }

 
    @Override
    public Boolean deleteProveedor (Long Nit) {
        this.proveedorRepository.deleteById(Nit);
        return true;
    }

}