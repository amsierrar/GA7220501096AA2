package com.proyectoEV3.prueba1.services;

import com.proyectoEV3.prueba1.model.Proveedor;

public interface ProveedorService {
    Proveedor newProveedor(Proveedor newProveedor);
    Iterable<Proveedor> getAll();
    Proveedor modifyProveedor(Proveedor proveedor);
    Boolean deleteProveedor(Long Nit);
    
        
    }


