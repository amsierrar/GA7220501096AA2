package com.proyectoEV3.prueba1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.proyectoEV3.prueba1.model.Proveedor;
import com.proyectoEV3.prueba1.services.ProveedorService;


@RestController
@RequestMapping("/proveedor")

public class ProveedorController {
  //  private static final String Id = null;
        @Autowired
        private ProveedorService proveedorService;
    
        @PostMapping("/nuevo")
        public Proveedor newProveedor(@RequestBody Proveedor newProveedor) {
            return this.proveedorService.newProveedor(newProveedor);
    
        }
        @GetMapping("/Mostrar")
        public Iterable<Proveedor> getAll() {
        return proveedorService.getAll();
        }
       
    @PostMapping ("/Modificar")
        public Proveedor updateProveedor(@RequestBody Proveedor proveedor) {
        return this.proveedorService.modifyProveedor(proveedor);
    
        }

      
    @PostMapping("/eliminar/{nit}")
public Boolean deleteProveedor(@PathVariable("id") Long id) {
    return this.proveedorService.deleteProveedor(id);
}
}
