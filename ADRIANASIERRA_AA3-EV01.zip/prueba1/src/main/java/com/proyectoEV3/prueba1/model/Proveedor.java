package com.proyectoEV3.prueba1.model;

import jakarta.persistence.Column;
//tengo que averiguar por que no se conecta con la base de datos.
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data

public class Proveedor{
    @Id
   @Column
    private Long Nit;
   @Column
    private String Nombre_proveedor;
    @Column
    private String Tel_proveedor;
    @Column
    private String Contacto_proveedor;
    @Column
    private String Correo_proveedor;
    @Column
    private String Dir_proveedor;
    @Column
    private String Ciudad_proveedor;
    @Column
    private String Pais_proveedor;
    @Column
    private String Observaciones_proveedor;

}
