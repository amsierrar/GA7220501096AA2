package com.proyectoEV3.prueba1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.proyectoEV3.prueba1.model.Proveedor;

public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {

}
